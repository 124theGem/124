#!/usr/bin/env bash
set -euo pipefail
umask 077
prostor_source=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
prostor_root=${PROSTOR_DIR:-"$HOME/prostor-preview"}
prostor_port=${PROSTOR_PORT:-18080}

command -v python3 >/dev/null || { echo 'Нужен Python 3. На Ubuntu: apt install python3'; exit 1; }
[[ -f "$prostor_source/site/index.html" ]] || { echo 'Запускайте start.sh из распакованного серверного архива.'; exit 1; }
[[ "$prostor_port" =~ ^[0-9]+$ ]] && ((prostor_port >= 1024 && prostor_port <= 65535)) || { echo 'Недопустимый порт.'; exit 1; }
if [[ -e "$prostor_root" && ! -f "$prostor_root/.prostor-preview-owned" ]]; then
  echo "Каталог $prostor_root уже существует и не принадлежит этому установщику. Остановка без изменений."
  exit 1
fi
mkdir -p -- "$prostor_root/releases"
prostor_root=$(cd -- "$prostor_root" && pwd -P)
printf '%s\n' 'prostor-preview-v1' > "$prostor_root/.prostor-preview-owned"

prostor_running=false
if [[ -f "$prostor_root/server.pid" ]]; then
  read -r prostor_pid < "$prostor_root/server.pid"
  if [[ "$prostor_pid" =~ ^[0-9]+$ ]] && kill -0 "$prostor_pid" 2>/dev/null; then
    if tr '\0' '\n' < "/proc/$prostor_pid/cmdline" | grep -Fxq -- "$prostor_root/serve.py"; then
      prostor_running=true
    else
      echo 'PID-файл указывает на посторонний процесс. Остановка без изменения процесса.'
      exit 1
    fi
  fi
fi
if [[ "$prostor_running" == false ]]; then
  python3 - "$prostor_port" <<'PY'
import socket, sys
try:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', int(sys.argv[1])))
except OSError:
    sys.exit('Порт занят. Другие службы не остановлены; укажите свободный PROSTOR_PORT.')
PY
fi
if [[ -e "$prostor_root/current" && ! -L "$prostor_root/current" ]]; then
  echo 'Путь current занят обычным каталогом или файлом. Существующие данные сохранены.'
  exit 1
fi
prostor_release=$(mktemp -d "$prostor_root/releases/release.XXXXXX")
cp -R -- "$prostor_source/site/." "$prostor_release/"
cp -- "$prostor_source/serve.py" "$prostor_root/serve.py"
cp -- "$prostor_source/stop.sh" "$prostor_root/stop.sh"
ln -s -- "$prostor_release" "$prostor_root/current.next"
mv -Tf -- "$prostor_root/current.next" "$prostor_root/current"
if [[ "$prostor_running" == false ]]; then
  nohup python3 "$prostor_root/serve.py" --root "$prostor_root/current" --port "$prostor_port" > "$prostor_root/server.log" 2>&1 < /dev/null &
  printf '%s\n' "$!" > "$prostor_root/server.pid"
fi
python3 - "$prostor_port" <<'PY'
import sys, time, urllib.request
for _ in range(50):
    try:
        with urllib.request.urlopen('http://127.0.0.1:'+sys.argv[1]+'/', timeout=1) as response:
            if 'Простор — планировщик помещений' in response.read().decode('utf-8'):
                print('Приложение запущено и проверено. Адрес привязки: 127.0.0.1, порт '+sys.argv[1]+'.')
                break
    except OSError:
        pass
    time.sleep(.1)
else:
    sys.exit('Проверка запуска не прошла. Посмотрите server.log в каталоге приложения.')
PY
echo "Каталог приложения: $prostor_root"
echo "Остановка: bash $prostor_root/stop.sh"
