#!/usr/bin/env bash
set -euo pipefail
prostor_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
[[ -f "$prostor_root/.prostor-preview-owned" ]] || { echo 'Нет маркера приложения. Остановка отменена.'; exit 1; }
[[ -f "$prostor_root/server.pid" ]] || { echo 'Приложение уже остановлено.'; exit 0; }
read -r prostor_pid < "$prostor_root/server.pid"
if [[ "$prostor_pid" =~ ^[0-9]+$ ]] && kill -0 "$prostor_pid" 2>/dev/null; then
  if tr '\0' '\n' < "/proc/$prostor_pid/cmdline" | grep -Fxq -- "$prostor_root/serve.py"; then
    kill "$prostor_pid"
    echo 'Тестовое приложение остановлено.'
  else
    echo 'PID относится к постороннему процессу. Он не остановлен.'
    exit 1
  fi
fi
rm -- "$prostor_root/server.pid"
